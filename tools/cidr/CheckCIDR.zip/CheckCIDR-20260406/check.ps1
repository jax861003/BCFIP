$cidrs = @(
    "173.245.48.0/20",
    "103.21.244.0/22",
    "103.22.200.0/22",
    "103.31.4.0/22",
    "141.101.64.0/18",
    "108.162.192.0/18",
    "190.93.240.0/20",
    "188.114.96.0/20",
    "197.234.240.0/22",
    "198.41.128.0/17",
    "162.158.0.0/15",
    "104.16.0.0/13",
    "104.24.0.0/14",
    "172.64.0.0/13",
    "131.0.72.0/22"
)

$outputFile = Join-Path $PSScriptRoot "cidr-best.txt"

# 爆率默认50%
# 并发，数值太大会导致测试不准确，建议20-200之间
$MaxThreads = 50

# 每个/24随机测试IP数量，数值越高测试越久，准确率越高
$TestCountPer24 = 6

# 每个/24必须满足至少有效IP数量，数值越高说明该号段有效IP越多，但满足高爆条件的CIDR会越少
$MinValidCount = 3

if (Test-Path $outputFile) { Remove-Item $outputFile }

# 第一步：拆解CIDR到/24网段
Write-Host "Step 1: Expanding CIDRs to /24 subnets..." -ForegroundColor Cyan
$Subnet24List = New-Object System.Collections.ArrayList

foreach ($cidr in $cidrs) {
    $network = $cidr -split '/' | Select-Object -First 1
    $mask = [int]($cidr -split '/')[1]
    $ipParts = $network.Split('.')
    
    $ipInt = ([long]$ipParts[0] -shl 24) + ([long]$ipParts[1] -shl 16) + ([long]$ipParts[2] -shl 8) + [long]$ipParts[3]
    $subnetMask = ([long]::MaxValue) -shl (32 - $mask)
    $networkInt = $ipInt -band $subnetMask
    $step = [long]1 -shl (32 - 24)
    $startInt = $networkInt
    $endInt = $networkInt -bor (-bnot $subnetMask)
    
    for ($currentInt = $startInt; $currentInt -le $endInt; $currentInt += $step) {
        if (($currentInt -band 0xFF) -eq 255) { continue }
        
        $o1 = ($currentInt -shr 24) -band 0xFF
        $o2 = ($currentInt -shr 16) -band 0xFF
        $o3 = ($currentInt -shr 8) -band 0xFF
        
        [void]$Subnet24List.Add("$o1.$o2.$o3")
    }
}

$TotalSubnets = $Subnet24List.Count
Write-Host "Total /24 subnets to test: $TotalSubnets" -ForegroundColor Green

# 第二步：生成测试IP
$TestIPsList = New-Object System.Collections.ArrayList
$SubnetForIP = New-Object System.Collections.ArrayList

foreach ($subnet in $Subnet24List) {
    $randomIPs = @{}
    while ($randomIPs.Count -lt $TestCountPer24) {
        $num = Get-Random -Minimum 1 -Maximum 254
        if (-not $randomIPs.ContainsKey($num)) {
            $randomIPs[$num] = $true
        }
    }
    
    foreach ($ip in $randomIPs.Keys) {
        [void]$TestIPsList.Add("$subnet.$ip")
        [void]$SubnetForIP.Add($subnet)
    }
}

$TotalTests = $TestIPsList.Count
Write-Host "Generated $TotalTests individual IP tests" -ForegroundColor Cyan

# 第三步：测试脚本块
$ScriptBlock = {
    Param($ip)
    
    try {
        $url = "http://$ip"
        $headers = @{"Host" = "cloudflare.com"}
        
        $response = Invoke-WebRequest -Uri $url -Headers $headers -TimeoutSec 2 -Method Head -UseBasicParsing -ErrorAction Stop
        
        if ($response.Headers["CF-RAY"] -or $response.Headers["Server"] -like "*cloudflare*") {
            return $true
        }
    } catch {
        if ($_.Exception.Response -and $_.Exception.Response.Headers["CF-RAY"]) {
            return $true
        }
    }
    return $false
}

# 第四步：并行测试
Write-Host "`nStep 2: Testing IPs in parallel..." -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor DarkGray

$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads)
$RunspacePool.Open()

$Jobs = New-Object System.Collections.ArrayList
$results = @{}
$lock = New-Object System.Object
$fileLock = New-Object System.Object  # 文件写入锁
$completed = 0
$validFound = @{}
$validSubnetsList = New-Object System.Collections.ArrayList

# 提交任务
for ($i = 0; $i -lt $TotalTests; $i++) {
    $ip = $TestIPsList[$i]
    $subnet = $SubnetForIP[$i]
    
    $ps = [powershell]::Create().AddScript($ScriptBlock).AddArgument($ip)
    $ps.RunspacePool = $RunspacePool
    $async = $ps.BeginInvoke()
    
    [void]$Jobs.Add(@{
        PowerShell = $ps
        Async = $async
        Subnet = $subnet
        IP = $ip
    })
}

# 收集结果 - 实时写入文件
$lastOutputTime = Get-Date
$lastPercent = 0

while ($Jobs.Count -gt 0) {
    $Done = $Jobs | Where-Object { $_.Async.IsCompleted }
    foreach ($Job in $Done) {
        $isValid = $Job.PowerShell.EndInvoke($Job.Async)
        
        if ($isValid) {
            [System.Threading.Monitor]::Enter($lock)
            try {
                if (-not $results.ContainsKey($Job.Subnet)) {
                    $results[$Job.Subnet] = 0
                }
                $results[$Job.Subnet]++
                
                # 达到有效数量时记录并实时写入文件
                if ($results[$Job.Subnet] -eq $MinValidCount -and -not $validFound.ContainsKey($Job.Subnet)) {
                    $validFound[$Job.Subnet] = $true
                    $validSubnet = "$($Job.Subnet).0/24"
                    [void]$validSubnetsList.Add($validSubnet)
                    
                    # 实时写入文件（线程安全）
                    [System.Threading.Monitor]::Enter($fileLock)
                    try {
                        Add-Content -Path $outputFile -Value $validSubnet -Encoding ASCII
                        Write-Host "[FOUND] $validSubnet" -ForegroundColor Green
                    } finally {
                        [System.Threading.Monitor]::Exit($fileLock)
                    }
                }
            } finally {
                [System.Threading.Monitor]::Exit($lock)
            }
        }
        
        $Job.PowerShell.Dispose()
        [void]$Jobs.Remove($Job)
        $completed++
    }
    
    # 每2秒显示一次进度
    $now = Get-Date
    if (($now - $lastOutputTime).TotalSeconds -ge 2) {
        $lastOutputTime = $now
        $percent = [Math]::Floor(($completed / $TotalTests) * 100)
        if ($percent -ne $lastPercent) {
            $lastPercent = $percent
            Write-Host "[PROGRESS] $percent% ($completed/$TotalTests) - Valid subnets: $($validSubnetsList.Count)" -ForegroundColor Yellow
        }
    }
    
    Start-Sleep -Milliseconds 200
}

# 显示最终进度
Write-Host "[PROGRESS] 100% ($TotalTests/$TotalTests) - Valid subnets: $($validSubnetsList.Count)" -ForegroundColor Yellow
Write-Host ""

$RunspacePool.Close()

# 最终统计
Write-Host "`n========== SUMMARY ==========" -ForegroundColor Yellow
Write-Host "Total /24 subnets tested: $TotalSubnets" -ForegroundColor Cyan
Write-Host "Valid /24 subnets found: $($validSubnetsList.Count)" -ForegroundColor Green
if ($TotalSubnets -gt 0) {
    Write-Host "Success rate: $([Math]::Round(($validSubnetsList.Count / $TotalSubnets) * 100, 2))%" -ForegroundColor Cyan
}
Write-Host "Results saved to: $outputFile" -ForegroundColor Yellow
Write-Host "=============================" -ForegroundColor Yellow

if ($validSubnetsList.Count -gt 0 -and $validSubnetsList.Count -le 50) {
    Write-Host "`nValid subnets:" -ForegroundColor Green
    $validSubnetsList | ForEach-Object { Write-Host "  $_" }
} elseif ($validSubnetsList.Count -gt 50) {
    Write-Host "`nFirst 20 valid subnets:" -ForegroundColor Green
    $validSubnetsList | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
    Write-Host "  ... and $($validSubnetsList.Count - 20) more"
}

pause