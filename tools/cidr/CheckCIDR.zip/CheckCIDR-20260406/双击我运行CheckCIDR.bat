@echo off
chcp 65001 >nul

powershell -Command "Write-Host '基于Cloudflare官方CIDR扫描高爆/24 - YouTube@真香定律' -ForegroundColor Cyan"
powershell -Command "Write-Host '-----------------------------------------' -ForegroundColor Cyan"
powershell -Command "Write-Host '测试前请关闭代理工具！测试时间会比较久！一个季度或半年扫描一次即可！' -ForegroundColor Cyan"
powershell -Command "Write-Host '-----------------------------------------' -ForegroundColor Cyan"
powershell -Command "Write-Host '默认爆率为百分之五十，可以在ps1中进行修改！' -ForegroundColor Cyan"
powershell -Command "Write-Host '-----------------------------------------' -ForegroundColor Cyan"
powershell -ExecutionPolicy Bypass -File "check.ps1"
pause